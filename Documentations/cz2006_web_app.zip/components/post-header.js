import DateFormatter from "../components/date-formatter";
import CoverImage from "../components/cover-image";
import PostTitle from "../components/post-title";
import Link from "next/link";

/**
 * Function to get and style post header
 * @param {post_data} Object store data of post geader
 * @returns {React.Fragment}
 */
export default function PostHeader({
  title,
  coverImage,
  date,
  author,
  RegURL,
}) {
  return (
    <>
      <div className="mb-8 md:mb-16 sm:mx-0">
        <CoverImage title={title} src={coverImage} height={620} width={1240} />
      </div>
      <PostTitle>{title}</PostTitle>
      {/* <div className="hidden md:block md:mb-12">
        <Avatar name={author.name} picture={author.picture} />
      </div> */}
      <div className="max-w-screen-xl mx-auto">
        {/* <div className="block md:hidden mb-6">
          <Avatar name={author.name} picture={author.picture} />
        </div> */}
        {/* <div className='mb-6 text-xl font-bold'>
          <DateFormatter dateString={date} />
        </div> */}
      </div>
    </>
  );
}
