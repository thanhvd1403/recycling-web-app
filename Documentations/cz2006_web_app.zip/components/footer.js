import { doc, getDoc, setDoc, Timestamp } from "@firebase/firestore";
import db from "../firebase-config";
import React, { useState } from "react";
import Swal from "sweetalert2";
import Link from "next/link";

/**
 * Function to render the footer of the web page.
 * @returns {React.HTMLProps}
 */
export default function Footer() {
  const [inputEmail, setInputEmail] = useState("");
  const handleChange = (event) => {
    setInputEmail(event.target.value);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    if (inputEmail != "") {
      const emailRef = doc(db, "emails", inputEmail);
      getDoc(emailRef).then((emailSnap) => {
        if (emailSnap.exists()) {
          Swal.fire({
            title: "Welcome back!",
            html: `<p>Email
                <strong>${inputEmail}</strong> 
                already exists!
                </p>`,
            icon: "info",
            color: "#000",
            // background: "url(/assets/recycle_alert.jpg) no-repeat fixed center",
            background: "#ECEFDA",
            backgroundSize: "cover",
            showConfirmButton: false,
            backdrop: `rgba(153, 241, 118, 0.4)`,
            timer: 3000,
          });
        } else {
          setDoc(emailRef, {
            subscriptionDate: Timestamp.now(),
          });
          Swal.fire({
            title: "Welcome on board!",
            html: `<p>Email
                <strong>${inputEmail}</strong> 
                added successfully!
                </p>`,
            icon: "success",
            color: "#000",
            // background: "url(/assets/recycle_alert.jpg) no-repeat fixed center",
            background: "#ECEFDA",
            showConfirmButton: false,
            backdrop: `rgba(153, 241, 118, 0.4)`,
            timer: 3000,
          });
        }
      });
    }
    setInputEmail("");
  };
  return (
    <footer className="text-center bg-gray-900 text-white">
      <div className="flex justify-center items-center lg:justify-between p-6 border-b border-gray-300">
        <div className="mr-12 hidden lg:block">
          <span>Get connected with us on social networks:</span>
        </div>

        <div className="flex justify-center">
          <a
            href="https://www.linkedin.com/in"
            className="mr-6 text-white underline"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="To LinkedIn"
          >
            <svg
              focusable="true"
              data-prefix="fab"
              data-icon="linkedin-in"
              className="w-3.5"
              role="img"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 448 512"
            >
              <path
                fill="currentColor"
                d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"
              ></path>
            </svg>
          </a>
          <a
            href="https://twitter.com/elonmusk"
            className="mr-6 text-white underline"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="To Twitter"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 48 48"
              focusable="true"
              data-prefix="fab"
              data-icon="linkedin-in"
              className="w-6"
              role="img"
            >
              <path
                fill="#03A9F4"
                d="M42,12.429c-1.323,0.586-2.746,0.977-4.247,1.162c1.526-0.906,2.7-2.351,3.251-4.058c-1.428,0.837-3.01,1.452-4.693,1.776C34.967,9.884,33.05,9,30.926,9c-4.08,0-7.387,3.278-7.387,7.32c0,0.572,0.067,1.129,0.193,1.67c-6.138-0.308-11.582-3.226-15.224-7.654c-0.64,1.082-1,2.349-1,3.686c0,2.541,1.301,4.778,3.285,6.096c-1.211-0.037-2.351-0.374-3.349-0.914c0,0.022,0,0.055,0,0.086c0,3.551,2.547,6.508,5.923,7.181c-0.617,0.169-1.269,0.263-1.941,0.263c-0.477,0-0.942-0.054-1.392-0.135c0.94,2.902,3.667,5.023,6.898,5.086c-2.528,1.96-5.712,3.134-9.174,3.134c-0.598,0-1.183-0.034-1.761-0.104C9.268,36.786,13.152,38,17.321,38c13.585,0,21.017-11.156,21.017-20.834c0-0.317-0.01-0.633-0.025-0.945C39.763,15.197,41.013,13.905,42,12.429"
              />
            </svg>
          </a>
          <a
            href="https://github.com/"
            className="text-white underline"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="To GitHub"
          >
            <svg
              focusable="true"
              data-prefix="fab"
              data-icon="github"
              className="w-4"
              role="img"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 496 512"
            >
              <path
                fill="currentColor"
                d="M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z"
              ></path>
            </svg>
          </a>
        </div>
      </div>

      <div className="mx-6 py-10 text-center md:text-left">
        <div className="grid grid-1 md:grid-cols-1 lg:grid-cols-4 gap-4 sx:block">
          <div className="col-span-2">
            <h6
              className="
              uppercase
              font-semibold
              mb-4
              flex
              items-center
              justify-center
              md:justify-start
              text-green
            "
            >
              <svg
                aria-hidden="true"
                focusable="false"
                data-prefix="fas"
                data-icon="cube"
                className="w-4 mr-3"
                role="img"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 512 512"
              >
                <path
                  fill="green"
                  d="M488.6 250.2L392 214V105.5c0-15-9.3-28.4-23.4-33.7l-100-37.5c-8.1-3.1-17.1-3.1-25.3 0l-100 37.5c-14.1 5.3-23.4 18.7-23.4 33.7V214l-96.6 36.2C9.3 255.5 0 268.9 0 283.9V394c0 13.6 7.7 26.1 19.9 32.2l100 50c10.1 5.1 22.1 5.1 32.2 0l103.9-52 103.9 52c10.1 5.1 22.1 5.1 32.2 0l100-50c12.2-6.1 19.9-18.6 19.9-32.2V283.9c0-15-9.3-28.4-23.4-33.7zM358 214.8l-85 31.9v-68.2l85-37v73.3zM154 104.1l102-38.2 102 38.2v.6l-102 41.4-102-41.4v-.6zm84 291.1l-85 42.5v-79.1l85-38.8v75.4zm0-112l-102 41.4-102-41.4v-.6l102-38.2 102 38.2v.6zm240 112l-85 42.5v-79.1l85-38.8v75.4zm0-112l-102 41.4-102-41.4v-.6l102-38.2 102 38.2v.6z"
                ></path>
              </svg>
              ONESTOP E-CYCLE
            </h6>
            <div>
              Torwards a greener country, transforming Singapore through
              Technology!
            </div>
          </div>

          <div className="">
            <h6 className="uppercase font-semibold mb-4 flex justify-center md:justify-start sx:pt-5">
              Useful links
            </h6>

            <p className="md:mb-4">
              <Link href="/info_page" passHref>
                <a
                  className="text-white hover:text-blue-400 hover:underline"
                  aria-label="Go to information page"
                >
                  E-waste Information
                </a>
              </Link>
            </p>

            <p className="md:mb-4 sx:pt-1">
              <Link href="/recycling_page" passHref>
                <a
                  className="text-white hover:text-blue-400 hover:underline"
                  aria-label="Go to recycling page"
                >
                  Recycling Hub
                </a>
              </Link>
            </p>

            <p className="mb-4 sx:py-1">
              <Link href="/events_page" passHref>
                <a
                  className="text-white hover:text-blue-400 hover:underline"
                  aria-label="Go to event page"
                >
                  Events
                </a>
              </Link>
            </p>
          </div>

          <div className="">
            <h6 className="uppercase font-semibold mb-4 flex justify-center md:justify-start">
              Contact
            </h6>
            <p className="flex items-center justify-center md:justify-start mb-4">
              <svg
                aria-hidden="true"
                focusable="false"
                data-prefix="fas"
                data-icon="home"
                className="w-4 mr-4"
                role="img"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 576 512"
              >
                <path
                  fill="currentColor"
                  d="M280.37 148.26L96 300.11V464a16 16 0 0 0 16 16l112.06-.29a16 16 0 0 0 15.92-16V368a16 16 0 0 1 16-16h64a16 16 0 0 1 16 16v95.64a16 16 0 0 0 16 16.05L464 480a16 16 0 0 0 16-16V300L295.67 148.26a12.19 12.19 0 0 0-15.3 0zM571.6 251.47L488 182.56V44.05a12 12 0 0 0-12-12h-56a12 12 0 0 0-12 12v72.61L318.47 43a48 48 0 0 0-61 0L4.34 251.47a12 12 0 0 0-1.6 16.9l25.5 31A12 12 0 0 0 45.15 301l235.22-193.74a12.19 12.19 0 0 1 15.3 0L530.9 301a12 12 0 0 0 16.9-1.6l25.5-31a12 12 0 0 0-1.7-16.93z"
                ></path>
              </svg>
              50 Nanyang Ave, Singapore 639798
            </p>
            <Link href="mailto: info@onestop.com" passHref>
              <p className="flex items-center justify-center md:justify-start mb-4 hover:underline hover:text-blue-400">
                <svg
                  aria-hidden="true"
                  focusable="false"
                  data-prefix="fas"
                  data-icon="envelope"
                  className="w-4 mr-4"
                  role="img"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 512 512"
                >
                  <path
                    fill="currentColor"
                    d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"
                  ></path>
                </svg>
                info@onestop.com
              </p>
            </Link>
            <Link href="tel:+65-99133199" passHref>
              <p className="flex items-center justify-center md:justify-start mb-4 hover:underline hover:text-blue-400">
                <svg
                  aria-hidden="true"
                  focusable="false"
                  data-prefix="fas"
                  data-icon="phone"
                  className="w-4 mr-4"
                  role="img"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 512 512"
                >
                  <path
                    fill="currentColor"
                    d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"
                  ></path>
                </svg>
                +65 99133199
              </p>
            </Link>
          </div>
        </div>
      </div>

      <div>
        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-3 gird-cols-1 gap-4 justify-center items-center">
            <div className="md:ml-auto md:mb-6">
              <p className="">
                <strong>Sign up for our newsletter</strong>
              </p>
            </div>

            <div className="md:mb-6">
              <input
                type="email"
                className="
                form-control
                block
                w-full
                px-3
                py-1.5
                text-base
                font-normal
                text-gray-700
                bg-white bg-clip-padding
                border border-solid border-gray-300
                rounded
                transition
                ease-in-out
                m-0
                focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none
              "
                id="exampleFormControlInput1"
                placeholder="Email address"
                value={inputEmail}
                onChange={handleChange}
              />
            </div>

            <div className="md:mr-auto mb-6">
              <button
                type="submit"
                className="inline-block px-6 py-2 border-2 border-white text-white font-medium text-xs leading-tight uppercase rounded hover:bg-white hover:bg-opacity-20 focus:outline-none focus:ring-0 transition ease-in-out"
              >
                Subscribe
              </button>
            </div>
          </div>
        </form>
      </div>
      <div className="text-center p-6 bg-gray-800">
        <span>© 2022 Copyright: </span>
        <a className="text-white font-semibold" href="!#">
          Onestop E-cycle @NTU
        </a>
      </div>
    </footer>
  );
}
