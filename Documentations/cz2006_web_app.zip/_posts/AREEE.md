---
title: 'Asia Conference on Renewable Energy and Environmental Engineering'
excerpt: 'The conference program will feature keynote and plenary sessions, oral and poster presentations. Distinguished speaker will be invited to deliver keynote speeches and invited talks on emerging technologies in renewable energy and enviromental engineering. Attendees will have the opportunity to interface with experts from all related fields. Prospective authors are invited to submit their papers in English. Interested parties without papers are also invited to participate as attendees at the conference as listeners.'
coverImage: '/assets/blog/AREEE/cover.jpg'
date: '2022-03-27T05:35:07.322Z'
author:
  name: JJ Kasper
  picture: '/assets/blog/authors/jj.jpeg'
RegURL: 'http://www.areee.org'
omImage: '/assets/faticon/logo.png'
---

The conference program will feature keynote and plenary sessions, oral and poster presentations. Distinguished speaker will be invited to deliver keynote speeches and invited talks on emerging technologies in renewable energy and enviromental engineering. Attendees will have the opportunity to interface with experts from all related fields. Prospective authors are invited to submit their papers in English. Interested parties without papers are also invited to participate as attendees at the conference as listeners.

---

---

**Timings:**
27 - 29 March 2022, 8AM - 6PM

**Venue:** To be confirmed

**Estimated turnaround:**
100 - 500 Delegates

**Categories & type:**
Conference, Environment & Waste, Power & Energy
